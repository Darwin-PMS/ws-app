import { useEffect, useRef, useCallback } from 'react';
import { Platform, Vibration } from 'react-native';
import * as ExpoSensor from 'expo-sensors';

// Hook for shake detection to trigger SOS
// Based on Disha app's 5-shake trigger functionality

const SHAKE_THRESHOLD = 2.5; // Sensitivity threshold
const SHAKE_INTERVAL = 500; // Minimum time between shakes (ms)
const REQUIRED_SHAKES = 5; // Number of shakes to trigger SOS (Disha app standard)
const TIME_WINDOW = 3000; // Time window to complete shakes (ms)

export const useShakeDetector = (onShakeTrigger, enabled = true) => {
    const shakeCount = useRef(0);
    const lastShakeTime = useRef(0);
    const shakeStartTime = useRef(0);
    const isAvailable = useRef(false);
    const subscriptionRef = useRef(null);

    const resetShakeCount = useCallback(() => {
        shakeCount.current = 0;
        shakeStartTime.current = 0;
    }, []);

    const handleShake = useCallback((data) => {
        if (!enabled) return;

        const currentTime = Date.now();

        // Check if enough time has passed since last shake
        if (currentTime - lastShakeTime.current < SHAKE_INTERVAL) {
            return;
        }

        // Calculate acceleration magnitude
        const { x, y, z } = data;
        const acceleration = Math.sqrt(x * x + y * y + z * z);

        // Check if acceleration exceeds threshold (excluding gravity ~9.8)
        if (acceleration > SHAKE_THRESHOLD) {
            lastShakeTime.current = currentTime;
            shakeCount.current += 1;

            // Record start time on first shake
            if (shakeCount.current === 1) {
                shakeStartTime.current = currentTime;
            }

            // Vibrate to give feedback
            Vibration.vibrate(50);

            // Check if shakes completed within time window
            const timeElapsed = currentTime - shakeStartTime.current;

            if (shakeCount.current >= REQUIRED_SHAKES && timeElapsed <= TIME_WINDOW) {
                // Trigger SOS
                onShakeTrigger?.();
                resetShakeCount();
            } else if (timeElapsed > TIME_WINDOW) {
                // Reset if time window exceeded
                resetShakeCount();
                // Start new count
                shakeCount.current = 1;
                shakeStartTime.current = currentTime;
            }
        }
    }, [enabled, onShakeTrigger, resetShakeCount]);

    useEffect(() => {
        const initSensor = async () => {
            if (!enabled) return;

            try {
                // Check if accelerometer is available
                const available = await ExpoSensor.Accelerometer.isAvailableAsync();
                isAvailable.current = available;

                if (available) {
                    // Set update interval (100ms for responsive detection)
                    ExpoSensor.Accelerometer.setUpdateInterval(100);

                    // Subscribe to accelerometer data
                    subscriptionRef.current = ExpoSensor.Accelerometer.addListener(handleShake);
                } else {
                    console.log('Accelerometer not available on this device');
                }
            } catch (error) {
                console.log('Error initializing shake detector:', error);
            }
        };

        initSensor();

        return () => {
            // Cleanup subscription on unmount
            if (subscriptionRef.current) {
                subscriptionRef.current.remove();
                subscriptionRef.current = null;
            }
        };
    }, [enabled, handleShake]);

    return {
        isAvailable: isAvailable.current,
        resetShakeCount,
    };
};

export default useShakeDetector;
