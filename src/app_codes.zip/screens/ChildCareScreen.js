import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';

const ChildCareScreen = () => {
    const { colors, spacing, borderRadius, shadows } = useTheme();

    const [activities, setActivities] = useState([
        { id: 1, title: 'Feeding Time', time: '08:00 AM', completed: true },
        { id: 2, title: 'Nap Time', time: '01:00 PM', completed: false },
        { id: 3, title: 'Play Time', time: '04:00 PM', completed: false },
        { id: 4, title: 'Bed Time', time: '08:00 PM', completed: false },
    ]);

    const toggleActivity = (id) => {
        setActivities(prev =>
            prev.map(activity =>
                activity.id === id ? { ...activity, completed: !activity.completed } : activity
            )
        );
    };

    const features = [
        { id: 'schedule', title: 'Daily Schedule', icon: 'calendar', color: colors.primary },
        { id: 'tracker', title: 'Growth Tracker', icon: 'trending-up', color: colors.success },
        { id: 'health', title: 'Health Records', icon: 'medical', color: colors.error },
        { id: 'milestones', title: 'Milestones', icon: 'trophy', color: colors.warning },
    ];

    return (
        <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
            <View style={[styles.header, { backgroundColor: colors.info }]}>
                <Ionicons name="happy" size={40} color={colors.white} />
                <Text style={[styles.headerTitle, { color: colors.white }]}>Child Care</Text>
                <Text style={[styles.headerSubtitle, { color: colors.white + 'CC' }]}>
                    Manage your child's daily activities
                </Text>
            </View>

            <View style={styles.content}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Quick Actions</Text>
                <View style={styles.featuresGrid}>
                    {features.map((feature) => (
                        <TouchableOpacity
                            key={feature.id}
                            style={[styles.featureCard, { backgroundColor: colors.card, borderRadius, ...shadows.small }]}
                            onPress={() => Alert.alert('Coming Soon', `${feature.title} feature coming soon`)}
                        >
                            <View style={[styles.featureIcon, { backgroundColor: feature.color + '20' }]}>
                                <Ionicons name={feature.icon} size={28} color={feature.color} />
                            </View>
                            <Text style={[styles.featureTitle, { color: colors.text }]}>{feature.title}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <Text style={[styles.sectionTitle, { color: colors.text, marginTop: spacing.lg }]}>Today's Schedule</Text>
                <View style={[styles.scheduleCard, { backgroundColor: colors.card, borderRadius, ...shadows.small }]}>
                    {activities.map((activity, index) => (
                        <TouchableOpacity
                            key={activity.id}
                            style={[
                                styles.activityItem,
                                index < activities.length - 1 && { borderBottomWidth: 1, borderColor: colors.border },
                            ]}
                            onPress={() => toggleActivity(activity.id)}
                        >
                            <View style={[styles.checkbox, { borderColor: activity.completed ? colors.success : colors.border }]}>
                                {activity.completed && <Ionicons name="checkmark" size={16} color={colors.success} />}
                            </View>
                            <View style={styles.activityContent}>
                                <Text style={[styles.activityTitle, { color: colors.text }]}>{activity.title}</Text>
                                <Text style={[styles.activityTime, { color: colors.gray }]}>{activity.time}</Text>
                            </View>
                            <View style={[styles.statusBadge, { backgroundColor: activity.completed ? colors.success + '20' : colors.warning + '20' }]}>
                                <Text style={[styles.statusText, { color: activity.completed ? colors.success : colors.warning }]}>
                                    {activity.completed ? 'Done' : 'Pending'}
                                </Text>
                            </View>
                        </TouchableOpacity>
                    ))}
                </View>

                <TouchableOpacity
                    style={[styles.addButton, { backgroundColor: colors.primary }]}
                    onPress={() => Alert.alert('Coming Soon', 'Add activity feature coming soon')}
                >
                    <Ionicons name="add" size={24} color={colors.white} />
                    <Text style={[styles.addButtonText, { color: colors.white }]}>Add Activity</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        alignItems: 'center',
        padding: 24,
        paddingTop: 48,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        marginTop: 12,
    },
    headerSubtitle: {
        fontSize: 14,
        marginTop: 4,
    },
    content: {
        padding: 16,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '600',
        marginBottom: 12,
    },
    featuresGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 12,
    },
    featureCard: {
        width: '47%',
        padding: 16,
        alignItems: 'center',
    },
    featureIcon: {
        width: 56,
        height: 56,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 12,
    },
    featureTitle: {
        fontSize: 14,
        fontWeight: '500',
    },
    scheduleCard: {
        overflow: 'hidden',
    },
    activityItem: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
    },
    checkbox: {
        width: 24,
        height: 24,
        borderRadius: 6,
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center',
    },
    activityContent: {
        flex: 1,
        marginLeft: 12,
    },
    activityTitle: {
        fontSize: 16,
        fontWeight: '500',
    },
    activityTime: {
        fontSize: 12,
        marginTop: 2,
    },
    statusBadge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
    },
    statusText: {
        fontSize: 12,
        fontWeight: '500',
    },
    addButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        height: 56,
        borderRadius: 12,
        gap: 8,
        marginTop: 24,
    },
    addButtonText: {
        fontSize: 18,
        fontWeight: '600',
    },
});

export default ChildCareScreen;
