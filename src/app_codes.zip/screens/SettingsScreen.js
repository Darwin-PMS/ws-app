import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Switch,
    Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';
import { useApp } from '../context/AppContext';

const SettingsScreen = ({ navigation }) => {
    const { colors, spacing, borderRadius, shadows, isDark, toggleTheme } = useTheme();
    const { logout } = useApp();

    const settingsGroups = [
        {
            title: 'Appearance',
            items: [
                { id: 'darkMode', title: 'Dark Mode', icon: 'moon-outline', type: 'switch', value: isDark, onValueChange: toggleTheme },
            ],
        },
        {
            title: 'Account',
            items: [
                { id: 'profile', title: 'Edit Profile', icon: 'person-outline', type: 'link', onPress: () => Alert.alert('Coming Soon') },
                { id: 'password', title: 'Change Password', icon: 'lock-closed-outline', type: 'link', onPress: () => Alert.alert('Coming Soon') },
            ],
        },
        {
            title: 'Notifications',
            items: [
                { id: 'push', title: 'Push Notifications', icon: 'notifications-outline', type: 'switch', value: true, onValueChange: () => { } },
                { id: 'email', title: 'Email Notifications', icon: 'mail-outline', type: 'switch', value: false, onValueChange: () => { } },
            ],
        },
        {
            title: 'Safety Resources',
            items: [
                { id: 'helpline', title: 'Emergency Helplines', icon: 'call-outline', type: 'link', onPress: () => navigation.navigate('EmergencyHelpline') },
                { id: 'grievance', title: 'File Complaint', icon: 'document-text-outline', type: 'link', onPress: () => navigation.navigate('Grievance') },
                { id: 'help', title: 'Help Center', icon: 'help-circle-outline', type: 'link', onPress: () => Alert.alert('Coming Soon') },
                { id: 'feedback', title: 'Send Feedback', icon: 'chatbubble-outline', type: 'link', onPress: () => Alert.alert('Coming Soon') },
                { id: 'about', title: 'About App', icon: 'information-circle-outline', type: 'link', onPress: () => Alert.alert('Women Safety App v1.0.0') },
                { id: 'privacy', title: 'Privacy Policy', icon: 'shield-outline', type: 'link', onPress: () => navigation.navigate('PrivacyPolicy') },
                { id: 'terms', title: 'Terms of Service', icon: 'document-text-outline', type: 'link', onPress: () => navigation.navigate('TermsOfService') },
            ],
        },
    ];

    const renderItem = (item, index, total) => {
        const isLast = index === total - 1;
        return (
            <View
                key={item.id}
                style={[styles.settingItem, !isLast && { borderBottomWidth: 1, borderColor: colors.border }]}
            >
                <Ionicons name={item.icon} size={22} color={colors.primary} />
                <Text style={[styles.settingText, { color: colors.text }]}>{item.title}</Text>
                {item.type === 'switch' ? (
                    <Switch value={item.value} onValueChange={item.onValueChange} />
                ) : (
                    <TouchableOpacity onPress={item.onPress} style={styles.linkContainer}>
                        <Ionicons name="chevron-forward" size={20} color={colors.gray} />
                    </TouchableOpacity>
                )}
            </View>
        );
    };

    return (
        <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
            <View style={styles.content}>
                {settingsGroups.map((group) => (
                    <View key={group.title} style={{ marginBottom: spacing.lg }}>
                        <Text style={[styles.groupTitle, { color: colors.gray }]}>{group.title}</Text>
                        <View style={[styles.card, { backgroundColor: colors.card, borderRadius, ...shadows.small }]}>
                            {group.items.map((item, index) => renderItem(item, index, group.items.length))}
                        </View>
                    </View>
                ))}

                <TouchableOpacity
                    style={[styles.logoutButton, { backgroundColor: colors.error + '15' }]}
                    onPress={() => Alert.alert('Logout', 'Are you sure?', [
                        { text: 'Cancel', style: 'cancel' },
                        { text: 'Logout', style: 'destructive', onPress: logout },
                    ])}
                >
                    <Ionicons name="log-out-outline" size={22} color={colors.error} />
                    <Text style={[styles.logoutText, { color: colors.error }]}>Logout</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    content: {
        padding: 16,
    },
    groupTitle: {
        fontSize: 13,
        fontWeight: '600',
        textTransform: 'uppercase',
        marginBottom: 8,
        marginLeft: 4,
    },
    card: {
        overflow: 'hidden',
    },
    settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
    },
    settingText: {
        flex: 1,
        fontSize: 16,
        marginLeft: 12,
    },
    linkContainer: {
        padding: 4,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
        borderRadius: 12,
        gap: 8,
        marginTop: 8,
    },
    logoutText: {
        fontSize: 16,
        fontWeight: '600',
    },
});

export default SettingsScreen;
