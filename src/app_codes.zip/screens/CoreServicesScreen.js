import React, { useMemo } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';
import { useSecondaryMenu } from '../context/MenuContext';
import { useNavigation } from '@react-navigation/native';

const CoreServicesScreen = () => {
    const { colors, spacing, borderRadius, shadows } = useTheme();
    const { items: menuItems, isLoading, isInitialized } = useSecondaryMenu();
    // Use useNavigation to get the correct navigation object from CoreServicesStack
    const navigation = useNavigation();

    // Transform menu items from backend to service cards
    const services = useMemo(() => {
        // If menu is still loading or no items, show default
        if (!isInitialized || isLoading || !menuItems || menuItems.length === 0) {
            return getDefaultServices(colors);
        }

        // Transform backend menu items to service format
        return menuItems.map(item => ({
            id: item.id,
            title: item.label || item.name,
            description: item.subtitle || '',
            icon: item.icon || 'apps',
            color: item.bgColor || item.bg_color || colors.primary,
            route: item.route,
            screen: item.route || item.screen,
            children: item.children || [],
            category: item.category,
        }));
    }, [menuItems, isLoading, isInitialized, colors]);

    // Fallback default services
    function getDefaultServices(colors) {
        return [
            {
                id: 'cylinder',
                title: 'Cylinder Verification',
                description: 'Verify gas cylinder validity & expiration',
                icon: 'flame',
                color: '#EF4444',
                screens: ['CylinderVerification'],
            },
            {
                id: 'ai',
                title: 'AI Services',
                description: 'Vision and Thought Generation',
                icon: 'sparkles',
                color: colors.primary,
                screens: ['Vision', 'ThoughtGenerator'],
            },
            {
                id: 'safety',
                title: 'Safety Features',
                description: 'Emergency alerts and family tracking',
                icon: 'shield',
                color: colors.error,
                screens: ['WomenSafety', 'FamilyLocation', 'BehaviorPattern'],
            },
            {
                id: 'training',
                title: 'Safety Training',
                description: 'AI-powered safety workshops & training',
                icon: 'school',
                color: '#9C27B0',
                screens: ['AISafetyWorkshop', 'FakeCall'],
            },
            {
                id: 'family',
                title: 'Family Management',
                description: 'Manage family members and relationships',
                icon: 'people',
                color: colors.success,
                screens: ['Family', 'CreateFamily', 'AddMember'],
            },
            {
                id: 'utilities',
                title: 'Voice & Text',
                description: 'Speech to text and text to speech',
                icon: 'mic',
                color: colors.secondary,
                screens: ['SpeechToText', 'TextToSpeech'],
            },
            {
                id: 'home',
                title: 'Home & Child Care',
                description: 'Smart home and child care management',
                icon: 'home',
                color: colors.accent,
                screens: ['HomeAutomation', 'ChildCare'],
            },

        ];
    }

    const handleServicePress = (service) => {
        // If service has children (from hierarchical menu), show options
        if (service.children && service.children.length > 0) {
            const options = service.children
                .filter(child => child.isVisible !== false)
                .map(child => ({
                    text: child.label || child.name,
                    onPress: () => {
                        const route = child.route || child.screen || child.name;
                        if (route) {
                            navigation.navigate(route);
                        }
                    },
                }));

            if (options.length > 0) {
                Alert.alert(
                    service.title,
                    'Choose an option:',
                    options.concat([{ text: 'Cancel', style: 'cancel' }])
                );
                return;
            }
        }

        // If service has a direct route/screen, navigate
        if (service.screen || service.route) {
            navigation.navigate(service.screen || service.route);
            return;
        }

        // Fallback to old behavior with screens array
        if (service.screens) {
            if (service.screens.length === 1) {
                navigation.navigate(service.screens[0]);
            } else if (service.screens.length > 1) {
                Alert.alert(
                    service.title,
                    'Choose an option:',
                    service.screens.map(screen => ({
                        text: screen.replace(/([A-Z])/g, ' $1').trim(),
                        onPress: () => navigation.navigate(screen),
                    })).concat([{ text: 'Cancel', style: 'cancel' }])
                );
            }
        }
    };

    if (isLoading && !isInitialized) {
        return (
            <View style={[styles.container, styles.loadingContainer, { backgroundColor: colors.background }]}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    return (
        <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
            <View style={[styles.header, { backgroundColor: colors.primary }]}>
                <Ionicons name="apps" size={40} color={colors.white} />
                <Text style={[styles.headerTitle, { color: colors.white }]}>Core Services</Text>
                <Text style={[styles.headerSubtitle, { color: colors.white + 'CC' }]}>
                    {menuItems && menuItems.length > 0
                        ? 'Powered by your menu configuration'
                        : 'Access all app features'}
                </Text>
            </View>

            <View style={styles.content}>
                {services.map((service) => (
                    <TouchableOpacity
                        key={service.id}
                        style={[styles.serviceCard, { backgroundColor: colors.card, borderRadius, ...shadows.small }]}
                        onPress={() => handleServicePress(service)}
                    >
                        <View style={[styles.iconContainer, { backgroundColor: service.color + '20' }]}>
                            <Ionicons name={service.icon} size={28} color={service.color} />
                        </View>
                        <View style={styles.serviceInfo}>
                            <Text style={[styles.serviceTitle, { color: colors.text }]}>{service.title}</Text>
                            <Text style={[styles.serviceDescription, { color: colors.gray }]}>
                                {service.description}
                            </Text>
                        </View>
                        {(service.children && service.children.length > 0) || (service.screens && service.screens.length > 1) ? (
                            <Ionicons name="chevron-forward" size={20} color={colors.gray} />
                        ) : null}
                    </TouchableOpacity>
                ))}
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    loadingContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    header: {
        alignItems: 'center',
        padding: 24,
        paddingTop: 48,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        marginTop: 12,
    },
    headerSubtitle: {
        fontSize: 14,
        marginTop: 4,
    },
    content: {
        padding: 16,
    },
    serviceCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        marginBottom: 12,
    },
    iconContainer: {
        width: 56,
        height: 56,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
    },
    serviceInfo: {
        flex: 1,
        marginLeft: 16,
    },
    serviceTitle: {
        fontSize: 18,
        fontWeight: '600',
    },
    serviceDescription: {
        fontSize: 14,
        marginTop: 4,
    },
});

export default CoreServicesScreen;
