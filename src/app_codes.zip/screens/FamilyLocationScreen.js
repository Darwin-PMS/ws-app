import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker } from 'react-native-maps';
import { useTheme } from '../context/ThemeContext';
import { useApp } from '../context/AppContext';
import familyService from '../services/familyService';

const FamilyLocationScreen = () => {
    const { colors, spacing, borderRadius, shadows } = useTheme();
    const { userId } = useApp();

    const [locations, setLocations] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedMember, setSelectedMember] = useState(null);

    useEffect(() => {
        loadFamilyLocations();
    }, []);

    const loadFamilyLocations = async () => {
        try {
            // First get user's families
            const familiesResponse = await familyService.getMyFamilies();
            if (familiesResponse.success && familiesResponse.data?.length > 0) {
                const familyId = familiesResponse.data[0].id;
                // Then get family locations
                const response = await familyService.getFamilyLocations(familyId);
                if (response.success) {
                    setLocations(response.data || []);
                    if (response.data?.length > 0) {
                        setSelectedMember(response.data[0]);
                    }
                }
            }
        } catch (error) {
            Alert.alert('Error', 'Failed to load family locations');
        } finally {
            setIsLoading(false);
        }
    };

    const getInitialRegion = () => {
        if (selectedMember?.location) {
            return {
                latitude: selectedMember.location.latitude,
                longitude: selectedMember.location.longitude,
                latitudeDelta: 0.01,
                longitudeDelta: 0.01,
            };
        }
        return {
            latitude: 37.78825,
            longitude: -122.4324,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
        };
    };

    if (isLoading) {
        return (
            <View style={[styles.container, { backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }]}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    return (
        <View style={[styles.container, { backgroundColor: colors.background }]}>
            <MapView
                style={styles.map}
                initialRegion={getInitialRegion()}
            >
                {locations.map((member) => (
                    member.location && (
                        <Marker
                            key={member.id}
                            coordinate={{
                                latitude: member.location.latitude,
                                longitude: member.location.longitude,
                            }}
                            title={`${member.firstName} ${member.lastName}`}
                            description={member.role}
                            onPress={() => setSelectedMember(member)}
                        />
                    )
                ))}
            </MapView>

            <View style={[styles.membersList, { backgroundColor: colors.card, ...shadows.medium }]}>
                <Text style={[styles.listTitle, { color: colors.text }]}>Family Members</Text>
                {locations.map((member) => (
                    <TouchableOpacity
                        key={member.id}
                        style={[
                            styles.memberItem,
                            selectedMember?.id === member.id && { backgroundColor: colors.primary + '20' },
                        ]}
                        onPress={() => setSelectedMember(member)}
                    >
                        <View style={[styles.memberAvatar, { backgroundColor: colors.primary }]}>
                            <Text style={[styles.memberInitial, { color: colors.white }]}>
                                {member.firstName?.[0]}{member.lastName?.[0]}
                            </Text>
                        </View>
                        <View style={styles.memberInfo}>
                            <Text style={[styles.memberName, { color: colors.text }]}>
                                {member.firstName} {member.lastName}
                            </Text>
                            <Text style={[styles.memberStatus, { color: colors.gray }]}>
                                {member.location ? 'Location available' : 'No location data'}
                            </Text>
                        </View>
                        <View style={[styles.statusDot, { backgroundColor: member.isOnline ? colors.success : colors.gray }]} />
                    </TouchableOpacity>
                ))}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    map: {
        flex: 1,
    },
    membersList: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        maxHeight: 250,
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        padding: 16,
    },
    listTitle: {
        fontSize: 18,
        fontWeight: '600',
        marginBottom: 12,
    },
    memberItem: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        borderRadius: 12,
        marginBottom: 8,
    },
    memberAvatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    memberInitial: {
        fontSize: 14,
        fontWeight: '600',
    },
    memberInfo: {
        flex: 1,
        marginLeft: 12,
    },
    memberName: {
        fontSize: 16,
        fontWeight: '500',
    },
    memberStatus: {
        fontSize: 12,
        marginTop: 2,
    },
    statusDot: {
        width: 10,
        height: 10,
        borderRadius: 5,
    },
});

export default FamilyLocationScreen;
