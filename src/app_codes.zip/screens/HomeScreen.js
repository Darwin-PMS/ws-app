import React, { useMemo } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';
import { useApp } from '../context/AppContext';
import { useSecondaryMenu } from '../context/MenuContext';
import BannerCarousel from '../components/BannerCarousel';

const HomeScreen = ({ navigation }) => {
    const { userName, isLoggedIn } = useApp();
    const { colors, spacing, borderRadius, shadows } = useTheme();
    const { items: menuItems, isLoading: menuLoading, isInitialized: menuInitialized } = useSecondaryMenu();

    // Helper function to handle navigation with nested navigator support
    const handleNavigation = (screen) => {
        // Screens in the 'More' (CoreServicesStack) nested navigator
        const nestedScreens = ['Vision', 'ThoughtGenerator', 'WomenSafety', 'Family', 'FamilyLocation', 'Settings', 'CylinderVerification', 'SafetyMap', 'FakeCall', 'SafeRoute', 'SpeechToText', 'TextToSpeech', 'AISafetyWorkshop', 'SmartLocation'];

        if (nestedScreens.includes(screen)) {
            navigation.navigate('More', { screen });
        } else {
            navigation.navigate(screen);
        }
    };

    // Transform menu items to features - use backend data if available
    const features = useMemo(() => {
        if (menuInitialized && !menuLoading && menuItems && menuItems.length > 0) {
            // Transform backend menu items to feature format
            return menuItems.slice(0, 6).map(item => ({
                id: item.id,
                title: item.label || item.name,
                subtitle: item.subtitle || item.category || '',
                icon: item.icon || 'apps',
                color: item.bgColor || item.bg_color || colors.primary,
                screen: item.route || item.screen || '',
            }));
        }
        // Fallback to default features
        return [
            { id: 'cylinder', title: 'Cylinder', subtitle: 'Verify gas cylinder', icon: 'flame', color: '#EF4444', screen: 'CylinderVerification' },
            { id: 'chat', title: 'AI Chat', subtitle: 'Chat with AI', icon: 'chatbubbles', color: colors.primary, screen: 'AIChat' },
            { id: 'vision', title: 'Vision', subtitle: 'Analyze images', icon: 'camera', color: colors.secondary, screen: 'Vision' },
            { id: 'smartLocation', title: 'Smart Location', subtitle: 'Advanced safety features', icon: 'location', color: '#10B981', screen: 'SmartLocation' },
            { id: 'thought', title: 'Thoughts', subtitle: 'Generate ideas', icon: 'sparkles', color: colors.accent, screen: 'ThoughtGenerator' },
            { id: 'safety', title: 'Safety', subtitle: 'Emergency features', icon: 'shield', color: colors.error, screen: 'WomenSafety' },
            { id: 'family', title: 'Family', subtitle: 'Manage family', icon: 'people', color: colors.success, screen: 'Family' },
            { id: 'location', title: 'Location', subtitle: 'Track family', icon: 'location', color: colors.info, screen: 'FamilyLocation' },
        ];
    }, [menuItems, menuLoading, menuInitialized, colors]);

    const quickActions = [
        { id: 'profile', title: 'Profile', icon: 'person', screen: 'Profile' },
        { id: 'settings', title: 'Settings', icon: 'settings', screen: 'Settings' },
        { id: 'notifications', title: 'Alerts', icon: 'notifications', screen: 'Notifications' },
    ];

    return (
        <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
            <View style={[styles.header, { backgroundColor: colors.primary }]}>
                <Text style={[styles.greeting, { color: colors.white }]}>
                    Hello, {userName || 'User'}!
                </Text>
                <Text style={[styles.subGreeting, { color: colors.white + 'CC' }]}>
                    Stay safe and connected
                </Text>
            </View>

            {/* Banner Carousel at Top */}
            <View style={styles.carouselContainer}>
                <BannerCarousel height={140} autoPlay={true} autoPlayInterval={4000} />
            </View>

            <View style={styles.content}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Features</Text>
                <View style={styles.featuresGrid}>
                    {features.map((feature) => (
                        <TouchableOpacity
                            key={feature.id}
                            style={[styles.featureCard, { backgroundColor: colors.card, borderRadius, ...shadows.small }]}
                            onPress={() => handleNavigation(feature.screen)}
                        >
                            <View style={[styles.iconContainer, { backgroundColor: feature.color + '20' }]}>
                                <Ionicons name={feature.icon} size={28} color={feature.color} />
                            </View>
                            <Text style={[styles.featureTitle, { color: colors.text }]}>{feature.title}</Text>
                            <Text style={[styles.featureSubtitle, { color: colors.gray }]}>{feature.subtitle}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <Text style={[styles.sectionTitle, { color: colors.text, marginTop: spacing.lg }]}>Quick Actions</Text>
                <View style={[styles.quickActions, { backgroundColor: colors.card, borderRadius, ...shadows.small }]}>
                    {quickActions.map((action, index) => (
                        <TouchableOpacity
                            key={action.id}
                            style={[styles.actionItem, index < quickActions.length - 1 && styles.actionBorder, { borderColor: colors.border }]}
                            onPress={() => handleNavigation(action.screen)}
                        >
                            <Ionicons name={action.icon} size={24} color={colors.primary} />
                            <Text style={[styles.actionText, { color: colors.text }]}>{action.title}</Text>
                            <Ionicons name="chevron-forward" size={20} color={colors.gray} />
                        </TouchableOpacity>
                    ))}
                </View>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        padding: 24,
        paddingTop: 48,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
    },
    greeting: {
        fontSize: 28,
        fontWeight: 'bold',
    },
    subGreeting: {
        fontSize: 16,
        marginTop: 4,
    },
    content: {
        padding: 16,
    },
    carouselContainer: {
        marginTop: -8,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: '600',
        marginBottom: 16,
    },
    featuresGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 12,
    },
    featureCard: {
        width: '47%',
        padding: 16,
        alignItems: 'center',
    },
    iconContainer: {
        width: 56,
        height: 56,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 12,
    },
    featureTitle: {
        fontSize: 16,
        fontWeight: '600',
        marginBottom: 4,
    },
    featureSubtitle: {
        fontSize: 12,
    },
    quickActions: {
        overflow: 'hidden',
    },
    actionItem: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
    },
    actionBorder: {
        borderBottomWidth: 1,
    },
    actionText: {
        flex: 1,
        fontSize: 16,
        marginLeft: 12,
    },
});

export default HomeScreen;
