// Safe Route Screen
// AI-powered safe route recommendations

import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    TextInput,
    Alert,
    ActivityIndicator,
} from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { useTheme } from '../context/ThemeContext';
import safeRouteService from '../services/safeRouteService';
import settingsService from '../services/settingsService';

const SafeRouteScreen = ({ navigation }) => {
    const { colors, spacing, borderRadius, shadows } = useTheme();

    const [origin, setOrigin] = useState('');
    const [destination, setDestination] = useState('');
    const [travelMode, setTravelMode] = useState('walking');
    const [location, setLocation] = useState(null);
    const [routeAnalysis, setRouteAnalysis] = useState(null);
    const [alternativeRoutes, setAlternativeRoutes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [safetyTips, setSafetyTips] = useState('');
    const [apiKeyConfigured, setApiKeyConfigured] = useState(false);

    useEffect(() => {
        initializeLocation();
        checkApiKey();
    }, []);

    const initializeLocation = async () => {
        try {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status === 'granted') {
                const userLocation = await Location.getCurrentPositionAsync({});
                setLocation(userLocation.coords);
            }
        } catch (error) {
            console.error('Location error:', error);
            setLocation({ latitude: 28.6139, longitude: 77.209 });
        }
    };

    const checkApiKey = async () => {
        try {
            const apiKey = await settingsService.getGroqApiKey();
            setApiKeyConfigured(!!apiKey);

            if (apiKey) {
                const tips = await safeRouteService.getSafetyTips();
                setSafetyTips(tips);
            }
        } catch (error) {
            console.error('Check API key error:', error);
        }
    };

    const handleAnalyzeRoute = async () => {
        if (!origin.trim() || !destination.trim()) {
            Alert.alert('Error', 'Please enter both origin and destination');
            return;
        }

        setLoading(true);
        try {
            // Get coordinates for origin and destination (simulated)
            const originCoords = location || { latitude: 28.6139, longitude: 77.209 };
            const destCoords = location ? {
                latitude: location.latitude + 0.01,
                longitude: location.longitude + 0.01,
            } : { latitude: 28.6239, longitude: 77.219 };

            const result = await safeRouteService.analyzeRoute(
                { ...originCoords, name: origin },
                { ...destCoords, name: destination },
                travelMode
            );

            if (result.success) {
                setRouteAnalysis(result);

                const alternatives = await safeRouteService.getAlternativeRoutes(
                    { ...originCoords, name: origin },
                    { ...destCoords, name: destination }
                );
                setAlternativeRoutes(alternatives);
            } else {
                Alert.alert('Error', result.error || 'Failed to analyze route');
            }
        } catch (error) {
            console.error('Analyze route error:', error);
            Alert.alert('Error', 'Failed to analyze route');
        } finally {
            setLoading(false);
        }
    };

    const getSafetyColor = (score) => {
        if (score >= 80) return '#10B981';
        if (score >= 60) return '#F59E0B';
        return '#EF4444';
    };

    const getSafetyLabel = (score) => {
        if (score >= 80) return 'Safe';
        if (score >= 60) return 'Moderate';
        return 'Caution';
    };

    const renderTravelModeSelector = () => (
        <View style={styles.modeSelector}>
            <TouchableOpacity
                style={[
                    styles.modeBtn,
                    { backgroundColor: travelMode === 'walking' ? colors.primary : colors.card }
                ]}
                onPress={() => setTravelMode('walking')}
            >
                <Ionicons
                    name="walk"
                    size={20}
                    color={travelMode === 'walking' ? '#fff' : colors.gray}
                />
                <Text style={[styles.modeBtnText, { color: travelMode === 'walking' ? '#fff' : colors.gray }]}>
                    Walking
                </Text>
            </TouchableOpacity>
            <TouchableOpacity
                style={[
                    styles.modeBtn,
                    { backgroundColor: travelMode === 'driving' ? colors.primary : colors.card }
                ]}
                onPress={() => setTravelMode('driving')}
            >
                <Ionicons
                    name="car"
                    size={20}
                    color={travelMode === 'driving' ? '#fff' : colors.gray}
                />
                <Text style={[styles.modeBtnText, { color: travelMode === 'driving' ? '#fff' : colors.gray }]}>
                    Driving
                </Text>
            </TouchableOpacity>
        </View>
    );

    return (
        <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
            {/* API Key Warning */}
            {!apiKeyConfigured && (
                <View style={[styles.warningBanner, { backgroundColor: '#FEF3C7' }]}>
                    <Ionicons name="warning" size={20} color="#D97706" />
                    <Text style={[styles.warningText, { color: '#92400E' }]}>
                        GROQ API key not configured. AI features limited.
                    </Text>
                </View>
            )}

            {/* Input Section */}
            <View style={[styles.inputSection, { backgroundColor: colors.card, ...shadows.small }]}>
                <View style={styles.inputRow}>
                    <View style={[styles.inputIcon, { backgroundColor: '#10B981' }]}>
                        <Ionicons name="location" size={20} color="#fff" />
                    </View>
                    <TextInput
                        style={[styles.input, { backgroundColor: colors.background, color: colors.text }]}
                        placeholder="From: Current Location"
                        placeholderTextColor={colors.gray}
                        value={origin}
                        onChangeText={setOrigin}
                    />
                </View>

                <View style={[styles.inputRow, { marginTop: 12 }]}>
                    <View style={[styles.inputIcon, { backgroundColor: '#EF4444' }]}>
                        <Ionicons name="flag" size={20} color="#fff" />
                    </View>
                    <TextInput
                        style={[styles.input, { backgroundColor: colors.background, color: colors.text }]}
                        placeholder="To: Enter destination"
                        placeholderTextColor={colors.gray}
                        value={destination}
                        onChangeText={setDestination}
                    />
                </View>

                {renderTravelModeSelector()}

                <TouchableOpacity
                    style={[styles.analyzeButton, { backgroundColor: colors.primary }]}
                    onPress={handleAnalyzeRoute}
                    disabled={loading}
                >
                    {loading ? (
                        <ActivityIndicator color="#fff" />
                    ) : (
                        <>
                            <Ionicons name="analytics" size={20} color="#fff" />
                            <Text style={styles.analyzeButtonText}>Analyze Route Safety</Text>
                        </>
                    )}
                </TouchableOpacity>
            </View>

            {/* Safety Tips */}
            {safetyTips && (
                <View style={[styles.tipsCard, { backgroundColor: colors.primary + '10', borderColor: colors.primary + '30' }]}>
                    <View style={styles.tipsHeader}>
                        <Ionicons name="shield-checkmark" size={24} color={colors.primary} />
                        <Text style={[styles.tipsTitle, { color: colors.text }]}>Safety Tips</Text>
                    </View>
                    <Text style={[styles.tipsText, { color: colors.gray }]}>{safetyTips}</Text>
                </View>
            )}

            {/* Route Analysis Results */}
            {routeAnalysis && (
                <View style={styles.resultsSection}>
                    <Text style={[styles.sectionTitle, { color: colors.text }]}>Route Analysis</Text>

                    {/* Safety Score */}
                    <View style={[styles.scoreCard, { backgroundColor: colors.card, ...shadows.medium }]}>
                        <View style={styles.scoreCircle}>
                            <Text style={[styles.scoreValue, { color: getSafetyColor(routeAnalysis.safetyScore) }]}>
                                {routeAnalysis.safetyScore}
                            </Text>
                            <Text style={[styles.scoreLabel, { color: colors.gray }]}>Safety Score</Text>
                        </View>
                        <View style={styles.scoreInfo}>
                            <View style={styles.scoreItem}>
                                <Ionicons name="alert-circle" size={20} color="#EF4444" />
                                <Text style={[styles.scoreItemText, { color: colors.text }]}>
                                    {routeAnalysis.incidents.origin + routeAnalysis.incidents.destination} incidents nearby
                                </Text>
                            </View>
                            <View style={styles.scoreItem}>
                                <Ionicons name="shield-checkmark" size={20} color="#10B981" />
                                <Text style={[styles.scoreItemText, { color: colors.text }]}>
                                    {routeAnalysis.safeZones.origin + routeAnalysis.safeZones.destination} safe zones
                                </Text>
                            </View>
                        </View>
                    </View>

                    {/* AI Analysis */}
                    {routeAnalysis.aiAnalysis && (
                        <View style={[styles.aiCard, { backgroundColor: colors.card, ...shadows.small }]}>
                            <View style={styles.aiHeader}>
                                <Ionicons name="brain" size={20} color={colors.primary} />
                                <Text style={[styles.aiTitle, { color: colors.text }]}>AI Analysis</Text>
                            </View>
                            <Text style={[styles.aiText, { color: colors.gray }]}>{routeAnalysis.aiAnalysis}</Text>
                        </View>
                    )}

                    {/* Recommendations */}
                    {routeAnalysis.recommendations && routeAnalysis.recommendations.length > 0 && (
                        <View style={[styles.recommendationsCard, { backgroundColor: colors.card, ...shadows.small }]}>
                            <Text style={[styles.recommendationsTitle, { color: colors.text }]}>Recommendations</Text>
                            {routeAnalysis.recommendations.map((rec, index) => (
                                <View key={index} style={styles.recommendationItem}>
                                    <Ionicons name="checkmark-circle" size={16} color={colors.primary} />
                                    <Text style={[styles.recommendationText, { color: colors.text }]}>{rec}</Text>
                                </View>
                            ))}
                        </View>
                    )}
                </View>
            )}

            {/* Alternative Routes */}
            {alternativeRoutes.length > 0 && (
                <View style={styles.resultsSection}>
                    <Text style={[styles.sectionTitle, { color: colors.text }]}>Alternative Routes</Text>
                    {alternativeRoutes.map((route) => (
                        <TouchableOpacity
                            key={route.id}
                            style={[styles.routeCard, { backgroundColor: colors.card, ...shadows.small }]}
                        >
                            <View style={styles.routeHeader}>
                                <Text style={[styles.routeName, { color: colors.text }]}>{route.name}</Text>
                                <View style={[styles.routeScore, { backgroundColor: getSafetyColor(route.safetyScore) + '20' }]}>
                                    <Text style={[styles.routeScoreText, { color: getSafetyColor(route.safetyScore) }]}>
                                        {route.safetyScore}%
                                    </Text>
                                </View>
                            </View>
                            <Text style={[styles.routeDesc, { color: colors.gray }]}>{route.description}</Text>
                            <View style={styles.routeMeta}>
                                <View style={styles.routeMetaItem}>
                                    <Ionicons name="time" size={16} color={colors.gray} />
                                    <Text style={[styles.routeMetaText, { color: colors.gray }]}>~{route.estimatedTime} min</Text>
                                </View>
                                <View style={styles.routeMetaItem}>
                                    <Ionicons name="navigate" size={16} color={colors.gray} />
                                    <Text style={[styles.routeMetaText, { color: colors.gray }]}>{route.distance} km</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    ))}
                </View>
            )}

            {/* How It Works */}
            <View style={[styles.howItWorksCard, { backgroundColor: colors.card, ...shadows.small }]}>
                <Text style={[styles.howItWorksTitle, { color: colors.text }]}>How It Works</Text>
                <View style={styles.step}>
                    <View style={[styles.stepNumber, { backgroundColor: colors.primary + '20' }]}>
                        <Text style={[styles.stepNumberText, { color: colors.primary }]}>1</Text>
                    </View>
                    <Text style={[styles.stepText, { color: colors.gray }]}>Enter your start and end locations</Text>
                </View>
                <View style={styles.step}>
                    <View style={[styles.stepNumber, { backgroundColor: colors.primary + '20' }]}>
                        <Text style={[styles.stepNumberText, { color: colors.primary }]}>2</Text>
                    </View>
                    <Text style={[styles.stepText, { color: colors.gray }]}>Select walking or driving mode</Text>
                </View>
                <View style={styles.step}>
                    <View style={[styles.stepNumber, { backgroundColor: colors.primary + '20' }]}>
                        <Text style={[styles.stepNumberText, { color: colors.primary }]}>3</Text>
                    </View>
                    <Text style={[styles.stepText, { color: colors.gray }]}>Get AI-powered safety analysis and recommendations</Text>
                </View>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    warningBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        margin: 16,
        borderRadius: 12,
        gap: 8,
    },
    warningText: {
        flex: 1,
        fontSize: 13,
    },
    inputSection: {
        margin: 16,
        padding: 16,
        borderRadius: 16,
    },
    inputRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    inputIcon: {
        width: 36,
        height: 36,
        borderRadius: 18,
        justifyContent: 'center',
        alignItems: 'center',
    },
    input: {
        flex: 1,
        marginLeft: 12,
        padding: 12,
        borderRadius: 12,
        fontSize: 14,
    },
    modeSelector: {
        flexDirection: 'row',
        marginTop: 16,
        gap: 12,
    },
    modeBtn: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        borderRadius: 12,
        gap: 8,
    },
    modeBtnText: {
        fontSize: 14,
        fontWeight: '500',
    },
    analyzeButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 14,
        borderRadius: 12,
        marginTop: 16,
        gap: 8,
    },
    analyzeButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    tipsCard: {
        margin: 16,
        marginTop: 0,
        padding: 16,
        borderRadius: 16,
        borderWidth: 1,
    },
    tipsHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginBottom: 8,
    },
    tipsTitle: {
        fontSize: 14,
        fontWeight: '600',
    },
    tipsText: {
        fontSize: 13,
        lineHeight: 20,
    },
    resultsSection: {
        padding: 16,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '600',
        marginBottom: 12,
    },
    scoreCard: {
        padding: 16,
        borderRadius: 16,
        flexDirection: 'row',
        alignItems: 'center',
    },
    scoreCircle: {
        width: 80,
        height: 80,
        borderRadius: 40,
        borderWidth: 4,
        borderColor: '#10B981',
        justifyContent: 'center',
        alignItems: 'center',
    },
    scoreValue: {
        fontSize: 28,
        fontWeight: 'bold',
    },
    scoreLabel: {
        fontSize: 10,
    },
    scoreInfo: {
        flex: 1,
        marginLeft: 16,
    },
    scoreItem: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 8,
        gap: 8,
    },
    scoreItemText: {
        fontSize: 13,
    },
    aiCard: {
        marginTop: 12,
        padding: 16,
        borderRadius: 16,
    },
    aiHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginBottom: 8,
    },
    aiTitle: {
        fontSize: 14,
        fontWeight: '600',
    },
    aiText: {
        fontSize: 13,
        lineHeight: 20,
    },
    recommendationsCard: {
        marginTop: 12,
        padding: 16,
        borderRadius: 16,
    },
    recommendationsTitle: {
        fontSize: 14,
        fontWeight: '600',
        marginBottom: 12,
    },
    recommendationItem: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        marginBottom: 8,
        gap: 8,
    },
    recommendationText: {
        flex: 1,
        fontSize: 13,
    },
    routeCard: {
        padding: 16,
        borderRadius: 16,
        marginBottom: 12,
    },
    routeHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 4,
    },
    routeName: {
        fontSize: 16,
        fontWeight: '600',
    },
    routeScore: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 12,
    },
    routeScoreText: {
        fontSize: 12,
        fontWeight: '600',
    },
    routeDesc: {
        fontSize: 13,
        marginBottom: 12,
    },
    routeMeta: {
        flexDirection: 'row',
        gap: 16,
    },
    routeMetaItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    routeMetaText: {
        fontSize: 12,
    },
    howItWorksCard: {
        margin: 16,
        padding: 16,
        borderRadius: 16,
    },
    howItWorksTitle: {
        fontSize: 16,
        fontWeight: '600',
        marginBottom: 16,
    },
    step: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    stepNumber: {
        width: 28,
        height: 28,
        borderRadius: 14,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    stepNumberText: {
        fontSize: 14,
        fontWeight: '600',
    },
    stepText: {
        flex: 1,
        fontSize: 13,
    },
});

export default SafeRouteScreen;
