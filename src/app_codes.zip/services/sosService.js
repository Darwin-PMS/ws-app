// SOS Service
// API calls for SOS alerts

import apiClient from './api/client';

export const sosService = {
    // Trigger SOS alert
    async triggerSOS(data = {}) {
        return apiClient.post('/sos/trigger', data);
    },

    // Get active SOS alerts
    async getActiveSOS() {
        return apiClient.get('/sos/active');
    },

    // Get SOS history
    async getSOSHistory(params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        const endpoint = `/sos/history${queryParams ? `?${queryParams}` : ''}`;
        return apiClient.get(endpoint);
    },

    // Resolve SOS alert
    async resolveSOS(alertId, resolutionData = {}) {
        return apiClient.put(`/sos/${alertId}/resolve`, resolutionData);
    },

    // Cancel SOS alert
    async cancelSOS(alertId) {
        return apiClient.delete(`/sos/${alertId}`);
    },

    // Update SOS location
    async updateSOSLocation(data = {}) {
        return apiClient.post('/sos/location-update', data);
    }
};

export default sosService;

