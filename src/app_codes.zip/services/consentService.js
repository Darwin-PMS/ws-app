// Consent Service
// API calls for consent management

import apiClient from './api/client';

export const consentService = {
    // Get consent settings
    async getConsentSettings() {
        return apiClient.get('/consent/consent-settings');
    },

    // Update consent settings
    async updateConsentSettings(consentData) {
        return apiClient.put('/consent/consent-settings', consentData);
    },

    // Update consent category
    async updateConsentCategory(category, value) {
        return apiClient.put('/consent/categories', { category, value });
    },

    // Get audit logs
    async getAuditLogs(params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/consent/audit-logs?${queryParams}`);
    }
};

export default consentService;
