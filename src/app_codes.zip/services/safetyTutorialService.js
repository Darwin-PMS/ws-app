// Safety Tutorial Service
// API calls for safety tutorials

import apiClient from './api/client';

export const safetyTutorialService = {
    // Get tutorials
    async getTutorials(params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/safety-tutorials?${queryParams}`);
    },

    // Get tutorial by ID
    async getTutorialById(id) {
        return apiClient.get(`/safety-tutorials/${id}`);
    },

    // Get categories
    async getCategories() {
        return apiClient.get('/safety-tutorials/categories');
    },

    // Search tutorials
    async searchTutorials(keyword) {
        return apiClient.get(`/safety-tutorials/search?q=${encodeURIComponent(keyword)}`);
    },

    // Get tutorials by category
    async getTutorialsByCategory(categoryId) {
        return apiClient.get(`/safety-tutorials/category/${categoryId}`);
    },

    // Get tutorials by difficulty
    async getTutorialsByDifficulty(difficulty) {
        return apiClient.get(`/safety-tutorials/difficulty/${difficulty}`);
    }
};

export default safetyTutorialService;
