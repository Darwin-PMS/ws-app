// Safety Law Service
// API calls for safety laws

import apiClient from './api/client';

export const safetyLawService = {
    // Get laws
    async getLaws(params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/safety-laws?${queryParams}`);
    },

    // Get law by ID
    async getLawById(id) {
        return apiClient.get(`/safety-laws/${id}`);
    },

    // Get categories
    async getCategories() {
        return apiClient.get('/safety-laws/categories');
    },

    // Get jurisdictions
    async getJurisdictions() {
        return apiClient.get('/safety-laws/jurisdictions');
    },

    // Search laws
    async searchLaws(keyword) {
        return apiClient.get(`/safety-laws/search?q=${encodeURIComponent(keyword)}`);
    },

    // Get laws by category
    async getLawsByCategory(categoryId) {
        return apiClient.get(`/safety-laws/category/${categoryId}`);
    },

    // Get laws by jurisdiction
    async getLawsByJurisdiction(jurisdictionId) {
        return apiClient.get(`/safety-laws/jurisdiction/${jurisdictionId}`);
    },

    // Get laws by category and jurisdiction
    async getLawsByCategoryAndJurisdiction(categoryId, jurisdictionId) {
        return apiClient.get(`/safety-laws?category=${categoryId}&jurisdiction=${jurisdictionId}`);
    },

    // Get recent laws
    async getRecentLaws(limit = 10) {
        return apiClient.get(`/safety-laws/recent?limit=${limit}`);
    }
};

export default safetyLawService;
