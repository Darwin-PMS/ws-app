// Event Service
// API calls for event tracking

import apiClient from './api/client';

export const eventService = {
    // Send location event
    async sendLocationEvent(familyId, locationData) {
        return apiClient.post(`/events/families/${familyId}/location`, locationData);
    },

    // Send batch location events
    async sendBatchLocationEvents(familyId, locations) {
        return apiClient.post(`/events/families/${familyId}/locations/batch`, { locations });
    },

    // Get suggestions
    async getSuggestions(familyId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/events/families/${familyId}/suggestions?${queryParams}`);
    },

    // Respond to suggestion
    async respondToSuggestion(suggestionId, response) {
        return apiClient.post(`/events/suggestions/${suggestionId}/respond`, { response });
    },

    // Get activity logs
    async getActivityLogs(familyId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/events/families/${familyId}/activity-logs?${queryParams}`);
    },

    // Create activity log
    async createActivityLog(familyId, logData) {
        return apiClient.post(`/events/families/${familyId}/activity-logs`, logData);
    },

    // Get family context
    async getFamilyContext(familyId) {
        return apiClient.get(`/events/families/${familyId}/context`);
    }
};

export default eventService;
