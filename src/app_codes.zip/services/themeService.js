// Theme Service
// API calls for theme management

import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient from './api/client';

const THEME_CACHE_KEY = '@app_theme_cache';
const THEME_CACHE_TIME_KEY = '@app_theme_cache_time';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

export const themeService = {
    // Get current theme
    async getCurrentTheme() {
        return apiClient.get('/themes/current');
    },

    // Get all themes
    async getAllThemes() {
        return apiClient.get('/themes');
    },

    // Update user theme
    async updateUserTheme(themeId) {
        return apiClient.put('/themes/user', { themeId });
    },

    // Get theme config
    async getThemeConfig(themeId) {
        return apiClient.get(`/themes/${themeId}/config`);
    },

    // Get cached theme
    async getCachedTheme() {
        try {
            const cached = await AsyncStorage.getItem(THEME_CACHE_KEY);
            if (cached) {
                return JSON.parse(cached);
            }
        } catch (e) {
            // Ignore
        }
        return null;
    },

    // Cache theme
    async cacheTheme(theme) {
        try {
            await AsyncStorage.setItem(THEME_CACHE_KEY, JSON.stringify(theme));
            await AsyncStorage.setItem(THEME_CACHE_TIME_KEY, Date.now().toString());
        } catch (e) {
            // Ignore
        }
    },

    // Clear theme cache
    async clearCache() {
        try {
            await AsyncStorage.multiRemove([THEME_CACHE_KEY, THEME_CACHE_TIME_KEY]);
        } catch (e) {
            // Ignore
        }
    }
};

// Default export for backward compatibility
export default themeService;
