// Context Service - Client-side service for location events and suggestions

import AsyncStorage from '@react-native-async-storage/async-storage';
import locationService from './locationService';
import { API_BASE_URL } from '@env';

class ContextService {
    constructor() {
        this.isWatching = false;
        this.currentFamilyId = null;
        this.suggestions = [];
        this.listeners = {
            onSuggestion: [],
            onLocationProcessed: [],
            onError: []
        };
    }

    // ==================== EVENT LISTENERS ====================

    addListener(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event].push(callback);
        }
    }

    removeListener(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
        }
    }

    emit(event, data) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(callback => callback(data));
        }
    }

    // ==================== LOCATION PERMISSIONS ====================

    // Request location permissions for context service
    async requestPermissions() {
        return await locationService.requestPermissions();
    }

    // Check if location services are enabled
    async isLocationServicesEnabled() {
        return await locationService.isLocationServicesEnabled();
    }

    // ==================== FAMILY CONTEXT ====================

    // Set the current family for context tracking
    async setCurrentFamily(familyId) {
        this.currentFamilyId = familyId;
        await AsyncStorage.setItem('currentFamilyId', familyId);
    }

    // Get the current family
    async getCurrentFamily() {
        if (!this.currentFamilyId) {
            this.currentFamilyId = await AsyncStorage.getItem('currentFamilyId');
        }
        return this.currentFamilyId;
    }

    // ==================== LOCATION TRACKING ====================

    // Start location tracking for context
    async startTracking() {
        if (this.isWatching) {
            return { success: false, message: 'Already tracking' };
        }

        const permission = await this.requestPermissions();
        if (!permission.success) {
            return { success: false, message: permission.message };
        }

        const familyId = await this.getCurrentFamily();
        if (!familyId) {
            return { success: false, message: 'No family selected' };
        }

        // Start watching location
        await locationService.startWatchingLocation(
            async (location) => {
                await this.processLocation(location);
            },
            {
                accuracy: locationService.Accuracy.Balanced,
                timeInterval: 60000, // 1 minute
                distanceInterval: 50, // 50 meters
            }
        );

        this.isWatching = true;
        return { success: true };
    }

    // Stop location tracking
    async stopTracking() {
        await locationService.stopWatchingLocation();
        this.isWatching = false;
        return { success: true };
    }

    // Process a location update
    async processLocation(location) {
        try {
            const familyId = await this.getCurrentFamily();
            if (!familyId) {
                return;
            }

            // Get auth token
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return;
            }

            // Send location to server
            const response = await fetch(`${API_BASE_URL}/api/families/${familyId}/location`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    latitude: location.latitude,
                    longitude: location.longitude,
                    accuracy: location.accuracy,
                    timestamp: new Date().toISOString()
                })
            });

            const data = await response.json();

            if (data.success && data.suggestion) {
                // Add to suggestions list
                this.suggestions.unshift(data.suggestion);

                // Emit suggestion event
                this.emit('onSuggestion', data.suggestion);
            }

            // Emit location processed event
            this.emit('onLocationProcessed', {
                location,
                processed: data.processed,
                reason: data.reason
            });

            return data;
        } catch (error) {
            console.error('Process location error:', error);
            this.emit('onError', error);
            return { success: false, error: error.message };
        }
    }

    // ==================== SUGGESTIONS ====================

    // Get pending suggestions
    async getSuggestions(familyId, status = 'pending') {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/families/${familyId}/suggestions?status=${status}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            const data = await response.json();

            if (data.success) {
                this.suggestions = data.suggestions;
            }

            return data;
        } catch (error) {
            console.error('Get suggestions error:', error);
            return { success: false, error: error.message };
        }
    }

    // Respond to a suggestion
    async respondToSuggestion(suggestionId, action, payload = {}) {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/suggestions/${suggestionId}/respond`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        action,
                        payload
                    })
                }
            );

            const data = await response.json();

            if (data.success && action === 'accepted') {
                // Remove from local suggestions
                this.suggestions = this.suggestions.filter(s => s.id !== suggestionId);
            }

            return data;
        } catch (error) {
            console.error('Respond to suggestion error:', error);
            return { success: false, error: error.message };
        }
    }

    // Accept a suggestion
    async acceptSuggestion(suggestionId, additionalData = {}) {
        return await this.respondToSuggestion(suggestionId, 'accepted', additionalData);
    }

    // Dismiss a suggestion
    async dismissSuggestion(suggestionId) {
        return await this.respondToSuggestion(suggestionId, 'dismissed');
    }

    // Snooze a suggestion
    async snoozeSuggestion(suggestionId, duration = 30) {
        return await this.respondToSuggestion(suggestionId, 'snoozed', { duration });
    }

    // ==================== ACTIVITY LOGS ====================

    // Get activity logs
    async getActivityLogs(familyId, options = {}) {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const { limit = 50, offset = 0, type } = options;
            let url = `${API_BASE_URL}/api/families/${familyId}/activity-logs?limit=${limit}&offset=${offset}`;
            if (type) {
                url += `&type=${type}`;
            }

            const response = await fetch(url, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            return await response.json();
        } catch (error) {
            console.error('Get activity logs error:', error);
            return { success: false, error: error.message };
        }
    }

    // Create activity log manually
    async createActivityLog(familyId, activityData) {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/families/${familyId}/activity-logs`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(activityData)
                }
            );

            return await response.json();
        } catch (error) {
            console.error('Create activity log error:', error);
            return { success: false, error: error.message };
        }
    }

    // ==================== FAMILY PLACES ====================

    // Get family places
    async getFamilyPlaces(familyId) {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/families/${familyId}/places`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            return await response.json();
        } catch (error) {
            console.error('Get family places error:', error);
            return { success: false, error: error.message };
        }
    }

    // Check location against family places
    async checkLocation(familyId, latitude, longitude) {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/families/${familyId}/places/check`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ latitude, longitude })
                }
            );

            return await response.json();
        } catch (error) {
            console.error('Check location error:', error);
            return { success: false, error: error.message };
        }
    }

    // ==================== CONSENT SETTINGS ====================

    // Get consent settings
    async getConsentSettings() {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/consent-settings`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            return await response.json();
        } catch (error) {
            console.error('Get consent settings error:', error);
            return { success: false, error: error.message };
        }
    }

    // Update consent settings
    async updateConsentSettings(settings) {
        try {
            const token = await AsyncStorage.getItem('authToken');
            if (!token) {
                return { success: false, message: 'Not authenticated' };
            }

            const response = await fetch(
                `${API_BASE_URL}/api/consent-settings`,
                {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(settings)
                }
            );

            return await response.json();
        } catch (error) {
            console.error('Update consent settings error:', error);
            return { success: false, error: error.message };
        }
    }

    // Enable location for family agent
    async enableLocationTracking() {
        return await this.updateConsentSettings({
            locationEnabled: true,
            familyAgentEnabled: true
        });
    }

    // Disable location for family agent
    async disableLocationTracking() {
        return await this.updateConsentSettings({
            locationEnabled: false
        });
    }
}

export default new ContextService();
