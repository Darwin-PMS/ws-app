// Child Care Service
// API calls for child care features

import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient from './api/client';

const TIPS_CACHE_KEY = '@childcare_tips_cache';
const TIPS_CACHE_TIME_KEY = '@childcare_tips_cache_time';
const CHAT_HISTORY_KEY = '@childcare_chat_history';
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour

export const childCareService = {
    // Get tips
    async getTips(params = {}) {
        try {
            const response = await apiClient.get('/childcare/tips', { params });
            if (response.success) {
                // Cache successful response
                try {
                    await AsyncStorage.setItem(TIPS_CACHE_KEY, JSON.stringify(response.tips || []));
                    await AsyncStorage.setItem(TIPS_CACHE_TIME_KEY, Date.now().toString());
                } catch (e) {
                    // Ignore cache errors
                }
            }
            return response;
        } catch (error) {
            // Try to return cached data on error
            try {
                const cached = await AsyncStorage.getItem(TIPS_CACHE_KEY);
                if (cached) {
                    return { success: true, tips: JSON.parse(cached), cached: true };
                }
            } catch (e) {
                // Ignore
            }
            throw error;
        }
    },

    // Get tip by ID
    async getTipById(tipId) {
        return apiClient.get(`/childcare/tips/${tipId}`);
    },

    // Add favorite
    async addFavorite(tipId) {
        return apiClient.post('/childcare/tips/favorites', { tipId });
    },

    // Remove favorite
    async removeFavorite(tipId) {
        return apiClient.delete(`/childcare/tips/favorites/${tipId}`);
    },

    // Get categories
    async getCategories() {
        return apiClient.get('/childcare/categories');
    },

    // Send message
    async sendMessage(conversationId, message, context = {}) {
        return apiClient.post('/childcare/chat/messages', { conversationId, message, context });
    },

    // Get conversations
    async getConversations() {
        return apiClient.get('/childcare/chat/conversations');
    },

    // Get conversation
    async getConversation(conversationId) {
        return apiClient.get(`/childcare/chat/conversations/${conversationId}`);
    },

    // Delete conversation
    async deleteConversation(conversationId) {
        return apiClient.delete(`/childcare/chat/conversations/${conversationId}`);
    },

    // Get chat history (local cache)
    async getChatHistory() {
        try {
            const history = await AsyncStorage.getItem(CHAT_HISTORY_KEY);
            return history ? JSON.parse(history) : [];
        } catch (error) {
            return [];
        }
    },

    // Save chat history (local cache)
    async saveChatHistory(messages) {
        try {
            await AsyncStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(messages));
        } catch (error) {
            // Ignore
        }
    },

    // Get children
    async getChildren() {
        return apiClient.get('/childcare/children');
    },

    // Add child
    async addChild(childData) {
        return apiClient.post('/childcare/children', childData);
    },

    // Update child
    async updateChild(childId, childData) {
        return apiClient.put(`/childcare/children/${childId}`, childData);
    },

    // Delete child
    async deleteChild(childId) {
        return apiClient.delete(`/childcare/children/${childId}`);
    },

    // Log growth
    async logGrowth(childId, entry) {
        return apiClient.post(`/childcare/trackers/growth/${childId}`, entry);
    },

    // Get growth logs
    async getGrowthLogs(childId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/childcare/trackers/growth/${childId}?${queryParams}`);
    },

    // Log feeding
    async logFeeding(childId, entry) {
        return apiClient.post(`/childcare/trackers/feeding/${childId}`, entry);
    },

    // Get feeding logs
    async getFeedingLogs(childId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/childcare/trackers/feeding/${childId}?${queryParams}`);
    },

    // Log sleep
    async logSleep(childId, entry) {
        return apiClient.post(`/childcare/trackers/sleep/${childId}`, entry);
    },

    // Get sleep logs
    async getSleepLogs(childId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/childcare/trackers/sleep/${childId}?${queryParams}`);
    },

    // Clear cache
    async clearCache() {
        const STORAGE_KEYS = {
            TIPS: '@childcare_tips_cache',
            TIPS_TIME: '@childcare_tips_cache_time',
            CHILDREN: '@childcare_children_cache',
            CONVERSATIONS: '@childcare_conversations_cache'
        };
        try {
            await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS));
        } catch (error) {
            // Ignore
        }
    }
};

// Default export for backward compatibility
export default childCareService;
