// Settings Service
// Handles fetching global application settings from the backend

import { apiClient } from './api/client';

class SettingsService {
    constructor() {
        this.cachedSettings = {};
    }

    /**
     * Initialize the API client (call this when app starts)
     */
    async initialize() {
        await apiClient.initialize();
    }

    /**
     * Get the Groq API key from the server
     * @returns {Promise<string|null>} The API key or null if not configured
     */
    async getGroqApiKey() {
        try {
            // Return cached key if available
            if (this.cachedSettings.groq_key) {
                return this.cachedSettings.groq_key;
            }

            const response = await apiClient.get('/settings/groq-key');

            if (response.success && response.data && response.data.key) {
                // Cache the key
                this.cachedSettings.groq_key = response.data.key;
                return response.data.key;
            }

            return null;
        } catch (error) {
            console.error('Error fetching Groq API key:', error);
            return null;
        }
    }

    /**
     * Clear the cached settings (useful after logout)
     */
    clearCache() {
        this.cachedSettings = {};
    }

    /**
     * Get a specific application setting by its key.
     * @param {string} key - The key of the setting to retrieve.
     * @returns {Promise<any>} The setting value.
     * @deprecated Use getGroqApiKey() instead for the Groq key
     */
    async getSetting(key) {
        if (key === 'groq_key') {
            return { data: { value: await this.getGroqApiKey() } };
        }
        throw new Error(`Unknown setting key: ${key}`);
    }
}

export default new SettingsService();
