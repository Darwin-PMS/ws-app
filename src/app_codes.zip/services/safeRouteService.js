// Safe Route Service
// AI-powered route safety recommendations using GROQ API

import { chatCompletion } from './groqApi';
import settingsService from './settingsService';
import safetyService from './safetyService';

class SafeRouteService {
    constructor() {
        this.apiKey = null;
    }

    async getApiKey() {
        if (!this.apiKey) {
            this.apiKey = await settingsService.getGroqApiKey();
        }
        return this.apiKey;
    }

    /**
     * Get safety analysis for a route
     * @param {Object} origin - { latitude, longitude, name }
     * @param {Object} destination - { latitude, longitude, name }
     * @param {string} mode - 'walking' or 'driving'
     * @returns {Promise<Object>} Safety analysis
     */
    async analyzeRoute(origin, destination, mode = 'walking') {
        try {
            const groqApiKey = await this.getApiKey();

            if (!groqApiKey) {
                return {
                    success: false,
                    error: 'GROQ API key not configured',
                };
            }

            // Get incidents along the route (simplified - in production, use actual route data)
            const originIncidents = await safetyService.getIncidentsNearLocation(
                origin.latitude, origin.longitude, 2
            );
            const destIncidents = await safetyService.getIncidentsNearLocation(
                destination.latitude, destination.longitude, 2
            );

            const originZones = await safetyService.getSafeZonesNearLocation(
                origin.latitude, origin.longitude, 2
            );
            const destZones = await safetyService.getSafeZonesNearLocation(
                destination.latitude, destination.longitude, 2
            );

            // Build context for AI analysis
            const context = this.buildRouteContext(origin, destination, mode, {
                originIncidents,
                destIncidents,
                originSafeZones: originZones,
                destSafeZones: destZones,
            });

            // Call GROQ API for AI-powered safety analysis
            const prompt = this.buildSafetyPrompt(context);

            const aiResponse = await chatCompletion(
                groqApiKey,
                [
                    {
                        role: 'system',
                        content: 'You are a safety expert AI assistant specializing in personal safety and route analysis. Analyze routes and provide safety recommendations based on lighting, crowd density, historical crime data, and time of day. Be concise and practical.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                'llama-3.3-70b-versatile',
                0.7,
                500
            );

            // Parse AI response and create structured result
            const safetyScore = this.calculateSafetyScore(originIncidents, destIncidents, originZones, destZones, mode);

            return {
                success: true,
                origin,
                destination,
                mode,
                safetyScore,
                aiAnalysis: aiResponse,
                incidents: {
                    origin: originIncidents.length,
                    destination: destIncidents.length,
                },
                safeZones: {
                    origin: originZones.length,
                    destination: destZones.length,
                },
                recommendations: this.extractRecommendations(aiResponse),
                timestamp: Date.now(),
            };
        } catch (error) {
            console.error('Route analysis error:', error);
            return {
                success: false,
                error: error.message,
            };
        }
    }

    buildRouteContext(origin, destination, mode, data) {
        const { originIncidents, destIncidents, originSafeZones, destSafeZones } = data;

        let context = `Analyze safety for a ${mode} route from ${origin.name || 'starting point'} to ${destination.name || 'destination'}.`;

        context += `\n\nCurrent conditions:`;
        context += `\n- Time: ${new Date().toLocaleTimeString()}`;
        context += `\n- Mode: ${mode}`;

        context += `\n\nIncidents near origin: ${originIncidents.length}`;
        if (originIncidents.length > 0) {
            context += ' (';
            context += originIncidents.slice(0, 3).map(i => i.type).join(', ');
            context += ')';
        }

        context += `\nIncidents near destination: ${destIncidents.length}`;
        if (destIncidents.length > 0) {
            context += ' (';
            context += destIncidents.slice(0, 3).map(i => i.type).join(', ');
            context += ')';
        }

        context += `\n\nSafe zones near origin: ${originSafeZones.length}`;
        context += `\nSafe zones near destination: ${destSafeZones.length}`;

        context += '\n\nProvide a safety assessment with:';
        context += '\n1. Overall safety rating (1-10)';
        context += '\n2. Key safety concerns';
        context += '\n3. Specific recommendations';
        context += '\n4. Alternative safer options if available';

        return context;
    }

    buildSafetyPrompt(context) {
        return context;
    }

    calculateSafetyScore(originIncidents, destIncidents, originZones, destZones, mode) {
        let score = 80; // Base score

        // Reduce for recent incidents
        const now = Date.now();
        const oneHourAgo = now - 60 * 60 * 1000;

        const recentOrigin = originIncidents.filter(i => i.timestamp > oneHourAgo).length;
        const recentDest = destIncidents.filter(i => i.timestamp > oneHourAgo).length;

        score -= recentOrigin * 10;
        score -= recentDest * 10;

        // Reduce for high severity incidents
        const highSeverityTypes = ['harassment', 'assault', 'stalking'];
        const highSeverityOrigin = originIncidents.filter(i => highSeverityTypes.includes(i.type)).length;
        const highSeverityDest = destIncidents.filter(i => highSeverityTypes.includes(i.type)).length;

        score -= highSeverityOrigin * 15;
        score -= highSeverityDest * 15;

        // Add for safe zones
        score += originZones.length * 5;
        score += destZones.length * 5;

        // Walking is generally less safe than driving at night
        if (mode === 'walking') {
            const hour = new Date().getHours();
            if (hour < 6 || hour > 22) {
                score -= 10;
            }
        }

        return Math.max(0, Math.min(100, score));
    }

    extractRecommendations(aiResponse) {
        const recommendations = [];

        // Simple extraction - in production, use more sophisticated parsing
        const lines = aiResponse.split('\n');

        for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('-') || trimmed.startsWith('•')) {
                recommendations.push(trimmed);
            }
        }

        return recommendations.length > 0 ? recommendations : ['Stay aware of your surroundings', 'Keep your phone charged'];
    }

    /**
     * Get alternative safer routes
     * @param {Object} origin
     * @param {Object} destination
     * @returns {Promise<Array>}
     */
    async getAlternativeRoutes(origin, destination) {
        // Generate simplified alternative routes
        // In production, use actual mapping API for real routes

        const baseRoute = {
            origin,
            destination,
            distance: this.calculateDistance(origin, destination),
        };

        return [
            {
                ...baseRoute,
                id: '1',
                name: 'Main Route',
                safetyScore: 70,
                estimatedTime: 15,
                description: 'Most direct route',
            },
            {
                ...baseRoute,
                id: '2',
                name: 'Via Main Road',
                safetyScore: 85,
                estimatedTime: 20,
                description: 'Better lit, more populated',
            },
            {
                ...baseRoute,
                id: '3',
                name: 'Via Police Station',
                safetyScore: 90,
                estimatedTime: 25,
                description: 'Passes by police station',
            },
        ];
    }

    calculateDistance(point1, point2) {
        const R = 6371; // Earth's radius in km
        const dLat = this.deg2rad(point2.latitude - point1.latitude);
        const dLon = this.deg2rad(point2.longitude - point1.longitude);
        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.deg2rad(point1.latitude)) * Math.cos(this.deg2rad(point2.latitude)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return (R * c).toFixed(1);
    }

    deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

    /**
     * Get real-time safety tips
     * @returns {Promise<string>}
     */
    async getSafetyTips() {
        try {
            const groqApiKey = await this.getApiKey();

            if (!groqApiKey) {
                return 'Stay aware of your surroundings and keep your phone accessible.';
            }

            const hour = new Date().getHours();
            let timeContext = 'day';
            if (hour < 6) timeContext = 'night (early morning)';
            else if (hour < 12) timeContext = 'morning';
            else if (hour < 18) timeContext = 'afternoon';
            else timeContext = 'evening';

            const prompt = `Provide 3-5 short, practical personal safety tips for walking during ${timeContext}. Keep each tip brief (max 10 words).`;

            const tips = await chatCompletion(
                groqApiKey,
                [
                    {
                        role: 'system',
                        content: 'You are a safety expert. Provide brief, practical safety tips.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                'llama-3.3-70b-versatile',
                0.7,
                200
            );

            return tips;
        } catch (error) {
            console.error('Get safety tips error:', error);
            return 'Stay aware of your surroundings and keep your phone accessible.';
        }
    }
}

export default new SafeRouteService();
