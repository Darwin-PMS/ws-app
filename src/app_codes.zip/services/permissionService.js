// Permission Service
// API calls for permission management

import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient from './api/client';

const PERMISSIONS_CACHE_KEY = '@app_permissions_cache';
const PERMISSIONS_CACHE_TIME_KEY = '@app_permissions_cache_time';
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour

export const permissionService = {
    // Get current permissions
    async getCurrentPermissions() {
        return apiClient.get('/permissions/current');
    },

    // Get all role permissions
    async getRolePermissions(role) {
        return apiClient.get(`/permissions/role/${role}`);
    },

    // Update user permissions
    async updatePermissions(permissions) {
        return apiClient.put('/permissions/user', permissions);
    },

    // Get cached permissions
    async getCachedPermissions() {
        try {
            const cached = await AsyncStorage.getItem(PERMISSIONS_CACHE_KEY);
            const cachedTime = await AsyncStorage.getItem(PERMISSIONS_CACHE_TIME_KEY);

            if (cached && cachedTime) {
                const age = Date.now() - parseInt(cachedTime);
                if (age < CACHE_DURATION) {
                    return JSON.parse(cached);
                }
            }
        } catch (e) {
            // Ignore
        }
        return null;
    },

    // Cache permissions
    async cachePermissions(permissions) {
        try {
            await AsyncStorage.setItem(PERMISSIONS_CACHE_KEY, JSON.stringify(permissions));
            await AsyncStorage.setItem(PERMISSIONS_CACHE_TIME_KEY, Date.now().toString());
        } catch (e) {
            // Ignore
        }
    },

    // Clear cached permissions
    async clearCachedPermissions() {
        try {
            await AsyncStorage.multiRemove([PERMISSIONS_CACHE_KEY, PERMISSIONS_CACHE_TIME_KEY]);
        } catch (e) {
            // Ignore
        }
    },

    // Check if user has a specific flag
    hasFlag(permissions, flagName) {
        if (!permissions || !permissions.flags) return false;
        return permissions.flags[flagName] === true;
    },

    // Check if user has permission for a resource/action
    hasPermission(permissions, resource, action) {
        if (!permissions || !permissions.permissions) return false;
        const resourcePerms = permissions.permissions[resource];
        if (!resourcePerms) return false;
        return resourcePerms.includes(action) || resourcePerms.includes('*');
    },

    // Check if user has any of the required roles
    hasAnyRole(permissions, requiredRoles) {
        if (!permissions || !permissions.roles) return false;
        const userRoles = Array.isArray(permissions.roles) ? permissions.roles : [permissions.roles];
        return requiredRoles.some(role => userRoles.includes(role));
    },

    // Check if user has all required roles
    hasAllRoles(permissions, requiredRoles) {
        if (!permissions || !permissions.roles) return false;
        const userRoles = Array.isArray(permissions.roles) ? permissions.roles : [permissions.roles];
        return requiredRoles.every(role => userRoles.includes(role));
    },

    // Check if a screen should be hidden
    isScreenHidden(permissions, screenName) {
        if (!permissions || !permissions.ui_restrictions) return false;
        return permissions.ui_restrictions.hiddenScreens?.includes(screenName);
    },

    // Check if a feature is disabled
    isFeatureDisabled(permissions, featureName) {
        if (!permissions || !permissions.ui_restrictions) return false;
        return permissions.ui_restrictions.disabledFeatures?.includes(featureName);
    },

    // Check if a field is read-only
    isFieldReadOnly(permissions, fieldName) {
        if (!permissions || !permissions.ui_restrictions) return false;
        return permissions.ui_restrictions.readOnlyFields?.includes(fieldName);
    },

    // Evaluate a custom condition
    evaluateCondition(permissions, condition) {
        if (!condition || !condition.type) return true;

        switch (condition.type) {
            case 'hasFlag':
                return this.hasFlag(permissions, condition.flag);
            case 'hasPermission':
                return this.hasPermission(permissions, condition.resource, condition.action);
            case 'hasRole':
                return this.hasAnyRole(permissions, [condition.role]);
            default:
                return true;
        }
    }
};

// Default export for backward compatibility
export default permissionService;
