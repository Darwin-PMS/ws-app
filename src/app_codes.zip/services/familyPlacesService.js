// Family Places Service
// API calls for family places (geofences)

import apiClient from './api/client';

export const familyPlacesService = {
    // Create place
    async createPlace(familyId, placeData) {
        return apiClient.post(`/family-places/${familyId}/places`, placeData);
    },

    // Get family places
    async getFamilyPlaces(familyId) {
        return apiClient.get(`/family-places/${familyId}/places`);
    },

    // Get place by ID
    async getPlaceById(familyId, placeId) {
        return apiClient.get(`/family-places/${familyId}/places/${placeId}`);
    },

    // Update place
    async updatePlace(familyId, placeId, placeData) {
        return apiClient.put(`/family-places/${familyId}/places/${placeId}`, placeData);
    },

    // Delete place
    async deletePlace(familyId, placeId) {
        return apiClient.delete(`/family-places/${familyId}/places/${placeId}`);
    },

    // Check location
    async checkLocation(familyId, latitude, longitude) {
        return apiClient.post(`/family-places/${familyId}/places/check`, { latitude, longitude });
    },

    // Find nearest place
    async findNearestPlace(familyId, latitude, longitude) {
        return apiClient.post(`/family-places/${familyId}/places/nearest`, { latitude, longitude });
    }
};

export default familyPlacesService;
