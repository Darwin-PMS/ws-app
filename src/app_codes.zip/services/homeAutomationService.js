// Home Automation Service
// API calls for home automation

import apiClient from './api/client';

export const getDevices = async () => {
    return apiClient.get('/home-automation/devices');
};

export const getDevice = async (deviceId) => {
    return apiClient.get(`/home-automation/devices/${deviceId}`);
};

export const addDevice = async (deviceData) => {
    return apiClient.post('/home-automation/devices', deviceData);
};

export const updateDevice = async (deviceId, deviceData) => {
    return apiClient.put(`/home-automation/devices/${deviceId}`, deviceData);
};

export const deleteDevice = async (deviceId) => {
    return apiClient.delete(`/home-automation/devices/${deviceId}`);
};

export const controlDevice = async (deviceId, command) => {
    return apiClient.post(`/home-automation/devices/${deviceId}/control`, command);
};

export const getRooms = async () => {
    return apiClient.get('/home-automation/rooms');
};

export const getDevicesByRoom = async (room) => {
    return apiClient.get(`/home-automation/rooms/${encodeURIComponent(room)}`);
};

export const getDevicesByType = async (deviceType) => {
    return apiClient.get(`/home-automation/types/${deviceType}`);
};

export const getStatistics = async () => {
    return apiClient.get('/home-automation/statistics');
};

export default {
    getDevices,
    getDevice,
    addDevice,
    updateDevice,
    deleteDevice,
    controlDevice,
    getRooms,
    getDevicesByRoom,
    getDevicesByType,
    getStatistics
};
