// Safety News Service
// API calls for safety news

import apiClient from './api/client';

export const safetyNewsService = {
    // Get news
    async getNews(params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return apiClient.get(`/safety-news?${queryParams}`);
    },

    // Get news by ID
    async getNewsById(id) {
        return apiClient.get(`/safety-news/${id}`);
    },

    // Get featured news
    async getFeaturedNews() {
        return apiClient.get('/safety-news/featured');
    },

    // Get categories
    async getCategories() {
        return apiClient.get('/safety-news/categories');
    },

    // Search news
    async searchNews(keyword) {
        return apiClient.get(`/safety-news/search?q=${encodeURIComponent(keyword)}`);
    },

    // Get news by category
    async getNewsByCategory(categoryId) {
        return apiClient.get(`/safety-news/category/${categoryId}`);
    },

    // Get latest news
    async getLatestNews(limit = 10) {
        return apiClient.get(`/safety-news/latest?limit=${limit}`);
    },

    // Get popular news
    async getPopularNews(limit = 10) {
        return apiClient.get(`/safety-news/popular?limit=${limit}`);
    }
};

export default safetyNewsService;
