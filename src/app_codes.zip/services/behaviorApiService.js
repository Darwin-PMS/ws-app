// Behavior Analysis API Service
// Frontend service to interact with the behavior analysis backend API

import databaseService from './databaseService';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEYS = {
    USER_ID: '@user_id',
};

// ========================
// Analyze Location
// ========================
const analyzeLocation = async (location, context = {}) => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI('/behavior/analyze', {
            method: 'POST',
            body: JSON.stringify({
                userId,
                location: {
                    latitude: location.latitude,
                    longitude: location.longitude,
                    accuracy: location.accuracy,
                    altitude: location.altitude,
                    heading: location.heading,
                    speed: location.speed,
                    timestamp: location.timestamp || new Date().toISOString()
                },
                context: {
                    activityType: context.activityType || 'unknown',
                    batteryLevel: context.batteryLevel,
                    isCharging: context.isCharging,
                    appState: context.appState
                }
            })
        });

        return response;
    } catch (error) {
        console.error('Analyze location error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Get Anomalies
// ========================
const getAnomalies = async (params = {}) => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const queryParams = new URLSearchParams({
            userId,
            ...params
        }).toString();

        const response = await databaseService.fetchAPI(`/behavior/anomalies?${queryParams}`);
        return response;
    } catch (error) {
        console.error('Get anomalies error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Get Behavior Summary
// ========================
const getBehaviorSummary = async () => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI(`/behavior/summary/${userId}`);
        return response;
    } catch (error) {
        console.error('Get behavior summary error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Submit Feedback
// ========================
const submitFeedback = async (anomalyId, feedbackType, notes = '', context = {}) => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI('/behavior/feedback', {
            method: 'POST',
            body: JSON.stringify({
                userId,
                anomalyId,
                feedbackType,
                notes,
                expectedBehavior: context.expectedBehavior,
                context: {
                    wasExpected: context.wasExpected || false,
                    reason: context.reason
                }
            })
        });

        return response;
    } catch (error) {
        console.error('Submit feedback error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Get Settings
// ========================
const getSettings = async () => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI(`/behavior/settings/${userId}`);
        return response;
    } catch (error) {
        console.error('Get settings error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Update Settings
// ========================
const updateSettings = async (settings) => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI(`/behavior/settings/${userId}`, {
            method: 'PUT',
            body: JSON.stringify(settings)
        });

        return response;
    } catch (error) {
        console.error('Update settings error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Get Routines
// ========================
const getRoutines = async () => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI(`/behavior/routines/${userId}`);
        return response;
    } catch (error) {
        console.error('Get routines error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Learn Routines
// ========================
const learnRoutines = async () => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI('/behavior/routines/learn', {
            method: 'POST',
            body: JSON.stringify({ userId })
        });

        return response;
    } catch (error) {
        console.error('Learn routines error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Get Alerts
// ========================
const getAlerts = async (params = {}) => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const queryParams = new URLSearchParams({
            userId,
            ...params
        }).toString();

        const response = await databaseService.fetchAPI(`/behavior/alerts/${userId}?${queryParams}`);
        return response;
    } catch (error) {
        console.error('Get alerts error:', error);
        return { success: false, error: error.message };
    }
};

// ========================
// Resolve Alert
// ========================
const resolveAlert = async (alertId, resolution, notes = '') => {
    const userId = await AsyncStorage.getItem(STORAGE_KEYS.USER_ID);

    if (!userId) {
        return { success: false, error: 'User not authenticated' };
    }

    try {
        const response = await databaseService.fetchAPI(`/behavior/alerts/${alertId}/resolve`, {
            method: 'PUT',
            body: JSON.stringify({
                userId,
                resolution,
                notes,
                responseTime: 0 // Would calculate actual response time
            })
        });

        return response;
    } catch (error) {
        console.error('Resolve alert error:', error);
        return { success: false, error: error.message };
    }
};

export default {
    analyzeLocation,
    getAnomalies,
    getBehaviorSummary,
    submitFeedback,
    getSettings,
    updateSettings,
    getRoutines,
    learnRoutines,
    getAlerts,
    resolveAlert
};
