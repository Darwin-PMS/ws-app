// Auth Service
// API calls for authentication

import apiClient from './api/client';

class AuthService {
    constructor() {
        apiClient.setTokenUpdateCallback(() => {
            // Token refreshed - could notify listeners if needed
        });
    }

    // Register
    async register(userData) {
        return apiClient.post('/auth/register', userData);
    }

    // Login
    async login(credentials) {
        return apiClient.post('/auth/login', credentials);
    }

    // Logout
    async logout(userId) {
        return apiClient.post('/auth/logout', { userId });
    }

    // Verify token
    async verifyToken() {
        return apiClient.get('/auth/verify');
    }
}

export default new AuthService();
