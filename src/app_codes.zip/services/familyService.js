// Family Service
// API calls for family management

import apiClient from './api/client';

export const familyService = {
    // Create family
    async createFamily(familyData) {
        return apiClient.post('/families', familyData);
    },

    // Get my families
    async getMyFamilies() {
        return apiClient.get('/families');
    },

    // Get family by ID
    async getFamilyById(familyId) {
        return apiClient.get(`/families/${familyId}`);
    },

    // Update family
    async updateFamily(familyId, familyData) {
        return apiClient.put(`/families/${familyId}`, familyData);
    },

    // Delete family
    async deleteFamily(familyId) {
        return apiClient.delete(`/families/${familyId}`);
    },

    // Get family members
    async getFamilyMembers(familyId) {
        return apiClient.get(`/families/${familyId}/members`);
    },

    // Add member
    async addMember(familyId, memberData) {
        return apiClient.post(`/families/${familyId}/members`, memberData);
    },

    // Remove member
    async removeMember(familyId, userId) {
        return apiClient.delete(`/families/${familyId}/members/${userId}`);
    },

    // Update member role
    async updateMemberRole(familyId, userId, role) {
        return apiClient.put(`/families/${familyId}/members/${userId}/role`, { role });
    },

    // Get relationships
    async getRelationships(familyId) {
        return apiClient.get(`/families/${familyId}/relationships`);
    },

    // Add relationship
    async addRelationship(familyId, relationshipData) {
        return apiClient.post(`/families/${familyId}/relationships`, relationshipData);
    },

    // Remove relationship
    async removeRelationship(familyId, relationshipId) {
        return apiClient.delete(`/families/${familyId}/relationships/${relationshipId}`);
    },

    // Find user by email
    async findUserByEmail(email) {
        return apiClient.get(`/families/users/lookup/${encodeURIComponent(email)}`);
    },

    // Get family locations
    async getFamilyLocations(familyId) {
        return apiClient.get(`/families/${familyId}/locations`);
    },

    // Get member location
    async getMemberLocation(familyId, userId) {
        return apiClient.get(`/families/${familyId}/members/${userId}/location`);
    }
};

export default familyService;

