// User Service
// Handles user-related API operations (profile, emergency contacts, notifications, settings)

import databaseService from './databaseService';

class UserService {
    // ==================== PROFILE ====================

    // Get user profile
    async getProfile(userId) {
        return databaseService.fetchAPI(`/users/${userId}`);
    }

    // Update user profile
    async updateProfile(userId, profileData) {
        return databaseService.fetchAPI(`/users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify(profileData),
        });
    }

    // Get user role
    async getUserRole(userId) {
        return databaseService.fetchAPI(`/users/${userId}/role`);
    }

    // ==================== EMERGENCY CONTACTS ====================

    // Get emergency contacts
    async getEmergencyContacts(userId) {
        return databaseService.fetchAPI(`/users/${userId}/emergency-contacts`);
    }

    // Add emergency contact
    async addEmergencyContact(userId, contactData) {
        return databaseService.fetchAPI(`/users/${userId}/emergency-contacts`, {
            method: 'POST',
            body: JSON.stringify(contactData),
        });
    }

    // Delete emergency contact
    async deleteEmergencyContact(userId, contactId) {
        return databaseService.fetchAPI(`/users/${userId}/emergency-contacts/${contactId}`, {
            method: 'DELETE',
        });
    }

    // ==================== NEW: DEFAULT + USER EMERGENCY CONTACTS ====================

    // Get all emergency contacts (default + user-specific)
    async getAllEmergencyContacts() {
        return databaseService.fetchAPI('/users/emergency-contacts/all');
    }

    // Get default emergency contacts only
    async getDefaultEmergencyContacts() {
        return databaseService.fetchAPI('/users/emergency-contacts/default');
    }

    // Get user emergency preferences
    async getEmergencyPreferences() {
        return databaseService.fetchAPI('/users/emergency-contacts/preferences');
    }

    // Update emergency preferences
    async updateEmergencyPreferences(preferences) {
        return databaseService.fetchAPI('/users/emergency-contacts/preferences', {
            method: 'PUT',
            body: JSON.stringify(preferences),
        });
    }

    // Add user emergency contact
    async addUserEmergencyContact(contactData) {
        return databaseService.fetchAPI('/users/emergency-contacts/all', {
            method: 'POST',
            body: JSON.stringify(contactData),
        });
    }

    // Update user emergency contact
    async updateUserEmergencyContact(contactId, contactData) {
        return databaseService.fetchAPI(`/users/emergency-contacts/all/${contactId}`, {
            method: 'PUT',
            body: JSON.stringify(contactData),
        });
    }

    // Delete user emergency contact
    async deleteUserEmergencyContact(contactId) {
        return databaseService.fetchAPI(`/users/emergency-contacts/all/${contactId}`, {
            method: 'DELETE',
        });
    }

    // ==================== LOCATION HISTORY ====================

    // Save location
    async saveLocation(userId, locationData) {
        return databaseService.fetchAPI(`/users/${userId}/locations`, {
            method: 'POST',
            body: JSON.stringify(locationData),
        });
    }

    // Get location history
    async getLocationHistory(userId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        const endpoint = `/users/${userId}/locations${queryParams ? `?${queryParams}` : ''}`;
        return databaseService.fetchAPI(endpoint);
    }

    // ==================== SOS ALERTS ====================

    // Get user SOS alerts
    async getSOSAlerts(userId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        const endpoint = `/users/${userId}/sos-alerts${queryParams ? `?${queryParams}` : ''}`;
        return databaseService.fetchAPI(endpoint);
    }

    // ==================== NOTIFICATIONS ====================

    // Get notifications
    async getNotifications(userId, params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        const endpoint = `/users/${userId}/notifications${queryParams ? `?${queryParams}` : ''}`;
        return databaseService.fetchAPI(endpoint);
    }

    // Mark notification as read
    async markNotificationRead(userId, notificationId) {
        return databaseService.fetchAPI(`/users/${userId}/notifications/${notificationId}/read`, {
            method: 'PUT',
        });
    }

    // Mark all notifications as read
    async markAllNotificationsRead(userId) {
        return databaseService.fetchAPI(`/users/${userId}/notifications/read-all`, {
            method: 'PUT',
        });
    }

    // ==================== USER CHILDREN (via user endpoint) ====================

    // Get children for user
    async getUserChildren(userId) {
        return databaseService.fetchAPI(`/users/${userId}/children`);
    }

    // Add child via user endpoint
    async addUserChild(userId, childData) {
        return databaseService.fetchAPI(`/users/${userId}/children`, {
            method: 'POST',
            body: JSON.stringify(childData),
        });
    }

    // ==================== USER SETTINGS ====================

    // Get user settings
    async getUserSettings(userId) {
        return databaseService.fetchAPI(`/users/${userId}/settings`);
    }

    // Update user settings
    async updateUserSettings(userId, settingsData) {
        return databaseService.fetchAPI(`/users/${userId}/settings`, {
            method: 'PUT',
            body: JSON.stringify(settingsData),
        });
    }
}

export default new UserService();
